package com.example.onmylist

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.os.Handler

class OnMyListActivity : AppCompatActivity() {

    private val SPLASH_TIME_OUT: Long = 5000
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_on_my_list)

        Handler().postDelayed({
            // Membuat intent untuk beralih ke MainActivity
            val intent = Intent(this, MainActivity::class.java)
            startActivity(intent)

            // Menutup activity saat ini
            finish()
        }, SPLASH_TIME_OUT)
    }
}