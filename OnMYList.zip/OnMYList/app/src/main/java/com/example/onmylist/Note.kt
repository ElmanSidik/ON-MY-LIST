package com.example.onmylist

data class Note(val id: Int, val title:String, val content:String)
