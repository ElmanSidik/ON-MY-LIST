package com.example.onmylist_uas

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
